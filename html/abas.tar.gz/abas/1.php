<?php
phpinfo();
?>



