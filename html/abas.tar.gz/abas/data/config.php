<?PHP 

//System Configurations

$config = array (

'charset' => 'utf-8',


);

?>