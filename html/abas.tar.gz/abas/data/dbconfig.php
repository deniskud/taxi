<?php                                                                                                                                         
define ("DBHOST", "localhost");

define ("DBNAME", "abas");

define ("DBUSER", "sasha");

define ("DBPASS", "0939944900@ua");

define ("COLLATE", "utf8mb4");

define('SECURE_AUTH_KEY', '[|r[U{3g>^Y(lpi/7](,A`de.! ;E4=ZVR&HkN%6kOauHe/Xjc7rn1xR7Ae{>odD');

$db = new db;

?>
